package id.jukentuneup

import android.Manifest
import android.app.Activity
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothSocket
import android.content.pm.PackageManager
import android.graphics.Typeface
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.*
import java.io.IOException
import java.util.UUID
import java.util.concurrent.Executors

class MainActivity : Activity() {
    private val sppUuid: UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")
    private val executor = Executors.newSingleThreadExecutor()
    private var socket: BluetoothSocket? = null
    private lateinit var status: TextView
    private lateinit var deviceSpinner: Spinner
    private lateinit var connectButton: Button
    private lateinit var content: LinearLayout
    private lateinit var nav: LinearLayout
    private var pairedDevices: List<BluetoothDevice> = emptyList()
    private var activePage = "Live"

    private val bg = 0xFF07111F.toInt()
    private val panel = 0xFF101E30.toInt()
    private val cyan = 0xFF37D9F2.toInt()
    private val muted = 0xFF9DAFC3.toInt()
    private val white = 0xFFF2F7FC.toInt()
    private val orange = 0xFFFFB547.toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        renderShell()
        showPage("Live")
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S &&
            checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.BLUETOOTH_CONNECT), 100)
        } else loadPairedDevices()
    }

    private fun label(value: String, size: Float, color: Int = white, bold: Boolean = false): TextView =
        TextView(this).apply {
            text = value
            textSize = size
            setTextColor(color)
            if (bold) setTypeface(typeface, Typeface.BOLD)
            setPadding(0, 5, 0, 5)
        }

    private fun card(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(16, 14, 16, 14)
        setBackgroundColor(panel)
    }

    private fun renderShell() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(bg)
        }
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(20, 18, 20, 12)
            setBackgroundColor(0xFF0A1728.toInt())
        }
        header.addView(label("JUKEN TUNE UP", 23f, cyan, true))
        header.addView(label("JUKEN 5+  •  ANDROID", 12f, muted, true))
        root.addView(header)

        content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(16, 14, 16, 18)
        }
        root.addView(ScrollView(this).apply {
            addView(content)
            layoutParams = LinearLayout.LayoutParams(-1, 0, 1f)
        })

        nav = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(4, 8, 4, 8)
            setBackgroundColor(0xFF0A1728.toInt())
        }
        listOf("Live", "Fuel", "Ignition", "Files", "Error").forEach { page ->
            nav.addView(Button(this).apply {
                text = page
                textSize = 10f
                isAllCaps = false
                setTextColor(if (page == activePage) cyan else muted)
                setBackgroundColor(0x00000000)
                setOnClickListener { showPage(page) }
                layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
            })
        }
        root.addView(nav)
        setContentView(root)
    }

    private fun showPage(page: String) {
        activePage = page
        content.removeAllViews()
        when (page) {
            "Live" -> buildDashboard()
            "Fuel" -> buildMapPage("FUEL MAP", "Tabel bahan bakar", "Editor menunggu format map Juken terverifikasi.")
            "Ignition" -> buildMapPage("IGNITION MAP", "Tabel pengapian", "Editor menunggu format map Juken terverifikasi.")
            "Files" -> buildFilesPage()
            "Error" -> buildErrorPage()
        }
        for (i in 0 until nav.childCount) {
            val b = nav.getChildAt(i) as Button
            b.setTextColor(if (b.text.toString() == page) cyan else muted)
        }
    }

    private fun buildDashboard() {
        content.addView(label("Dashboard", 22f, white, true))
        val connection = card()
        connection.orientation = LinearLayout.HORIZONTAL
        connection.gravity = Gravity.CENTER_VERTICAL
        status = label("●  Belum terhubung", 14f, orange, true)
        connection.addView(status, LinearLayout.LayoutParams(0, -2, 1f))
        connectButton = Button(this).apply {
            text = "Hubungkan"
            isAllCaps = false
            setOnClickListener { connectSelected() }
        }
        connection.addView(connectButton)
        content.addView(connection, marginParams(top = 8, bottom = 14))

        val rpmCard = card()
        rpmCard.gravity = Gravity.CENTER
        rpmCard.addView(label("ENGINE RPM", 12f, muted, true))
        rpmCard.addView(label("--", 46f, cyan, true))
        rpmCard.addView(label("rpm  •  menunggu data ECU", 12f, muted))
        content.addView(rpmCard, marginParams(bottom = 10))

        val row1 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        row1.addView(metricCard("TPS", "--", "%"), LinearLayout.LayoutParams(0, -2, 1f).apply { rightMargin = 6 })
        row1.addView(metricCard("MAP", "--", "kPa"), LinearLayout.LayoutParams(0, -2, 1f).apply { leftMargin = 6 })
        content.addView(row1, marginParams(bottom = 10))
        val row2 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        row2.addView(metricCard("SUHU MESIN", "--", "°C"), LinearLayout.LayoutParams(0, -2, 1f).apply { rightMargin = 6 })
        row2.addView(metricCard("TEGANGAN", "--", "V"), LinearLayout.LayoutParams(0, -2, 1f).apply { leftMargin = 6 })
        content.addView(row2, marginParams(bottom = 12))

        val note = card()
        note.addView(label("MODE SIMULASI", 12f, orange, true))
        note.addView(label("Angka sensor belum berasal dari ECU. Koneksi Bluetooth saja belum mengaktifkan pembacaan data; protokol Juken harus diverifikasi terlebih dahulu.", 13f, muted))
        content.addView(note)
    }

    private fun metricCard(title: String, value: String, unit: String): LinearLayout {
        val c = card()
        c.addView(label(title, 11f, muted, true))
        c.addView(label(value, 27f, white, true))
        c.addView(label(unit, 12f, cyan))
        return c
    }

    private fun buildMapPage(title: String, subtitle: String, description: String) {
        content.addView(label(title, 22f, cyan, true))
        content.addView(label(subtitle, 15f, muted))
        val c = card()
        c.addView(label("MAP EDITOR", 13f, cyan, true))
        c.addView(label(description, 14f, white))
        c.addView(label("Langkah selanjutnya: validasi format file dan ukuran tabel asli sebelum mengizinkan edit atau pengiriman ke ECU.", 12f, muted))
        content.addView(c, marginParams(top = 12))
    }

    private fun buildFilesPage() {
        content.addView(label("MAP FILES", 22f, cyan, true))
        val c = card()
        c.addView(label("Penyimpanan lokal", 16f, white, true))
        c.addView(label("Fitur simpan dan buka map akan menggunakan file lokal setelah format map Juken diketahui.", 13f, muted))
        val button = Button(this).apply {
            text = "Penyimpanan map belum aktif"
            isAllCaps = false
            isEnabled = false
        }
        c.addView(button)
        content.addView(c, marginParams(top = 10))
    }

    private fun buildErrorPage() {
        content.addView(label("DIAGNOSTICS", 22f, cyan, true))
        val c = card()
        c.addView(label("Kode Error ECU", 16f, white, true))
        c.addView(label("Belum ada kode yang dibaca. Pembacaan diagnostik memerlukan perintah dan format respons Juken 5+ yang terverifikasi.", 13f, muted))
        content.addView(c, marginParams(top = 10))
    }

    private fun marginParams(top: Int = 0, bottom: Int = 0): LinearLayout.LayoutParams =
        LinearLayout.LayoutParams(-1, -2).apply { topMargin = top; bottomMargin = bottom }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 100 && grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            loadPairedDevices()
        } else if (::status.isInitialized) {
            status.text = "Izin Bluetooth diperlukan"
        }
    }

    private fun loadPairedDevices() {
        val adapter = BluetoothAdapter.getDefaultAdapter()
        if (adapter == null) {
            if (::status.isInitialized) status.text = "Bluetooth tidak tersedia"
            return
        }
        try {
            pairedDevices = adapter.bondedDevices.toList().sortedBy { it.name ?: it.address }
            if (::status.isInitialized && pairedDevices.isEmpty()) {
                status.text = "Pair adaptor lewat Pengaturan Bluetooth Android"
            }
        } catch (_: SecurityException) {
            if (::status.isInitialized) status.text = "Izin Bluetooth belum diberikan"
        }
    }

    private fun connectSelected() {
        // The UI starter does not yet include a device picker to avoid guessing which paired device is the ECU.
        val adapter = BluetoothAdapter.getDefaultAdapter()
        if (adapter == null) {
            status.text = "Bluetooth tidak tersedia"
            return
        }
        try {
            pairedDevices = adapter.bondedDevices.toList().sortedBy { it.name ?: it.address }
        } catch (_: SecurityException) {
            status.text = "Izin Bluetooth belum diberikan"
            return
        }
        if (pairedDevices.isEmpty()) {
            status.text = "Pair adaptor di Pengaturan Bluetooth Android"
            return
        }
        // Ask the user to confirm the actual adaptor rather than connecting to an arbitrary paired device.
        val names = pairedDevices.map { "${it.name ?: "Tanpa nama"} (${it.address})" }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("Pilih adaptor Juken")
            .setItems(names) { _, which -> connectDevice(pairedDevices[which]) }
            .setNegativeButton("Batal", null)
            .show()
    }

    private fun connectDevice(device: BluetoothDevice) {
        connectButton.isEnabled = false
        status.text = "Menghubungkan..."
        executor.execute {
            try {
                socket?.close()
                val newSocket = device.createRfcommSocketToServiceRecord(sppUuid)
                newSocket.connect()
                socket = newSocket
                runOnUiThread {
                    status.text = "Terhubung • ${device.name ?: device.address}"
                    connectButton.isEnabled = true
                    connectButton.text = "Pilih perangkat"
                }
                // No ECU commands are sent until the Juken 5+ protocol is verified.
            } catch (e: Exception) {
                try { socket?.close() } catch (_: IOException) {}
                socket = null
                runOnUiThread {
                    status.text = "Gagal terhubung • periksa adaptor/pairing"
                    connectButton.isEnabled = true
                }
            }
        }
    }

    override fun onDestroy() {
        try { socket?.close() } catch (_: IOException) {}
        executor.shutdownNow()
        super.onDestroy()
    }
}
