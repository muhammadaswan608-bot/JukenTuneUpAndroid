# Juken Tune Up Android — starter 0.1.0

Fondasi Android native Kotlin untuk Juken 5+ dan adaptor Bluetooth Classic SPP.

## Fitur awal
- Dashboard UI dengan nilai sensor placeholder (SIMULASI)
- Menampilkan perangkat Bluetooth yang sudah dipasangkan
- Mencoba koneksi RFCOMM memakai UUID SPP standar
- Tombol placeholder Fuel Map, Ignition Map, penyimpanan map, dan kode error

## Penting
- Koneksi Bluetooth berhasil **tidak** berarti protokol ECU sudah diketahui.
- Aplikasi ini tidak mengirim perintah ECU apa pun.
- Nilai sensor bukan data nyata.
- Jangan gunakan untuk tuning motor sungguhan sebelum protokol, skala data, checksum, dan respons ECU diverifikasi.
- Untuk Android 12+, izin BLUETOOTH_CONNECT diminta saat aplikasi berjalan.

## Build
Buka proyek ini dengan Android Studio, atau unggah ke repository GitHub dan siapkan GitHub Actions workflow untuk membangun APK. Untuk menguji SPP, gunakan perangkat Android fisik; emulator umumnya tidak bisa mengakses adaptor Bluetooth ECU secara langsung.
